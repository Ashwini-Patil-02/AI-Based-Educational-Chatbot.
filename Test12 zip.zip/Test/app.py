from flask import Flask,render_template
import pyttsx3
import datetime
import speech_recognition as sr
import webbrowser
import wikipedia

app = Flask(__name__)

@app.route("/")
def main():
    return render_template('/index.html')

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
# print(voices[1].id)
engine.setProperty('voice', voices[1].id)


def speak(audio):
    engine.say(audio)
    engine.runAndWait()

@app.route("/wishme/")
def wishMe():
    hour = int(datetime.datetime.now().hour)
    if hour >= 0 and hour < 12:
        speak("Good Morning Sir and mam!!,Hello Everyone I am Shiksha . how may i help you")
    elif hour >= 12 and hour < 18:
        speak("Good Afternoon Sir and mam,Hello Everyone I am Shiksha . how may i help you")
    else:
        speak("good evening,Hello Everyone I am Shiksha . how may i help you")


@app.route("/takecommand/")
def takeCommand():
    # It takes microphone input from the user and returns string output
        
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        r.adjust_for_ambient_noise(source, duration=1)
        audio = r.listen(source)
    

    try:
        print("Recognizing...")
        query = r.recognize_google(audio, language='en-in')  # Using google for voice recognition.
        query = query.lower()
        if 'open google' in query:
            webbrowser.open('https://www.google.com/')

        elif 'open youtube' in query:
            webbrowser.open("https://youtube.com")

        if 'dbms lecture' in query:
            webbrowser.open('https://www.youtube.com/watch?v=kBdlM6hNDAE&list=PLxCzCOWd7aiFAN6I8CuViBuCdJgiOkT2Y')

        if 'dbms notes' in query:
            webbrowser.open('http://elearning.sscoetjalgaon.ac.in/moodle/course/view.php?id=111')

        if 'wikipedia' in query:
            speak("Searching Results")
            query = query.replace("wikipedia", "")
            results = wikipedia.summary(query, sentences=2)
            speak("sir!! According Search Results")
            print(results)
            speak(results)

        print(f"User said: {query}\n")  # User query will be printed.

    except Exception as e:
        # print(e)
        print("Say that again please...")  # Say that again will be printed in case of improper voice
        return "None"  # None string will be returned
    return query


if __name__ == "__main__":
    wishMe()
    